#include <stdio.h>
#include <lpc17xx.h>
#include <stdlib.h>
#include "delay.h"

#define ir 10
#define sw1 11
#define sw2 12
#define fix_cost 20
#define kw 0.7
#define MAX 5
#define SBIT_CLKEN   0  //RTC Clock Enable
#define SBIT_CTCRST  1  //RTC Clock Reset
#define SBIT_CCALEN  4  //RTC Calibration counter enable
uint8_t hour, min, sec, date, month;
uint32_t irStatus;
uint32_t sw1status;
uint32_t sw2status;


int i,k,counter1,array[100],t1,t2,t3,t4;//t1,t2-sec t3,t4-min
char buf[50],input;
float charge_time;

void enable_rtc()
{
    /* Disable RTC clock, reset clock, Enable RTC calibration */
    LPC_RTC->CCR = ((1 << SBIT_CTCRST ) | (1 << SBIT_CCALEN));
    LPC_RTC->CALIBRATION = 0x00;
    LPC_RTC->CCR = (1 << SBIT_CLKEN);    /* Enable the clock for RTC */

    /* Set Date and Time only once, comment these lines after setting the time and date */   
    // Set Date 
    LPC_RTC->DOM    = 5;   // Update date value 
    LPC_RTC->MONTH  = 12;   // Update month value
    LPC_RTC->YEAR   = 2023; // Update year value

    // Set Time 
    LPC_RTC->HOUR   = 00;   // Update hour value 
    LPC_RTC->MIN    = 00;   // Update min value
    LPC_RTC->SEC    = 00;   // Update sec value 
}

void UART0_Init(void) 
{
  LPC_SC->PCONP |= 0x00000008;        // UART0 peripheral enable
  LPC_PINCON->PINSEL0 &= ~0x000000F0;
  LPC_PINCON->PINSEL0 |= 0x00000050;  // P0.2 - TXD0 and P0.3 - RXD0
  LPC_UART0->LCR = 0x00000083;       // enable divisor latch, parity disable, 1 stop bit, 8bit word length
  LPC_UART0->DLM = 0X00; 
  LPC_UART0->DLL = 0xA2;             // select baud rate 9600 bps @25MHz
  LPC_UART0->LCR = 0X00000003;
  LPC_UART0->FCR = 0x07;
  LPC_UART0->IER = 0X03;               // select Transmit and receive interrupt
} 

void print(char buf[])
{
  i=0;
      while (buf[i]!= '\0')
      {
        while (!(LPC_UART0->LSR & 0x20));
        LPC_UART0->THR =buf[i];
        DELAY_ms(1);
        i++;
      }
      while (!(LPC_UART0->LSR & 0x20));
      LPC_UART0->THR = '\t';
}

unsigned char receive()
{
  while(!(LPC_UART0->LSR &0X01));
  return(LPC_UART0->RBR);
}

void cal_bill()
{
	float kwh,tariff,ta1,ta2;
	counter1--;sw1status=0;
	hour = LPC_RTC->HOUR;
  min  = LPC_RTC->MIN; 
  sec  = LPC_RTC->SEC;
	t2=LPC_RTC->SEC;
	t4=LPC_RTC->MIN;
	sprintf(buf,"Time:%2d:%2d\t",min,sec);
  print(buf);

	if(t3!=t4)
	{
		t1=60-t1;charge_time=t2+t1;
	}
	else 
		charge_time=t2-t1;
	kwh=kw*charge_time;
	if((t3>=18 && t3<24) && (t4>=18 && t4<24))
    tariff=(double)((float)fix_cost+(kwh*9));
  else if((t3>=0 && t3<6) && (t4>=0 && t4<6))
		tariff=(double)((float)fix_cost+(kwh*9));
  else if((t3>=6 && t3<10) && (t4>=6 && t4<10))
    tariff=(double)((float)fix_cost+(kwh*8));
	else if((t3>=10 && t3<14) && (t4>=10 && t4<14))
    tariff=(double)((float)fix_cost+(kwh*7));
  else if((t3>=14 && t3<18) && (t4>=14 && t4<18))
    tariff=(double)((float)fix_cost+(kwh*8));
  if((t3>=18 && t3<24) && (t4>=0 && t4<6))
	{
		t1=60-t1;
		ta1=(double)((float)fix_cost+(kw*9*t1));
		ta2=(double)((float)fix_cost+(kw*9*t2));
		tariff=ta1+ta2;
	}
	else if((t3>=0 && t3<6) && (t4>=6 && t4<10))
	{
		t1=60-t1;
		ta1=(double)((float)fix_cost+(kw*9*t1));
		ta2=(double)((float)fix_cost+(kw*8*t2));
		tariff=ta1+ta2;
	}
	else if((t3>=6 && t3<10) && (t4>=10 && t4<14))
	{
		t1=60-t1;
		ta1=(double)((float)fix_cost+(kw*8*t1));
		ta2=(double)((float)fix_cost+(kw*7*t2));
		tariff=ta1+ta2;
	}
	else if((t3>=10 && t3<114) && (t4>=14 && t4<18))
	{
		t1=60-t1;
		ta1=(double)((float)fix_cost+(kw*8*t1));
		ta2=(double)((float)fix_cost+(kw*7*t2));
		tariff=ta1+ta2;
	}
	else if((t3>=14 && t3<18) && (t4>=18 && t4<24))
	{
		t1=60-t1;
		ta1=(double)((float)fix_cost+(kw*8*t1));
		ta2=(double)((float)fix_cost+(kw*9*t2));
		tariff=ta1+ta2;
		sprintf(buf,"ta1=%f\tta2=%f \n",ta1,ta2);
		print(buf);
	}
	sprintf(buf,"t1=%d\tt2=%d\nBill=%f \n",t1,t2,tariff);print(buf);
	array[k]=tariff;
	k++;
	t1=t2;
	t3=t4;
}

int main(void) 
{          
    SystemInit();
		enable_rtc();
    UART0_Init();counter1=0;
    SystemCoreClockUpdate(); 
		k=0;
	
	 LPC_PINCON->PINSEL2 = 0x000000;
	 LPC_GPIO2->FIODIR = ((0<<ir) | (0<<sw1) | (0<<sw2)); 
	 while (counter1<=5)
    {
      irStatus=(LPC_GPIO2->FIOSET>>ir) & 0x01;
      sw1status=(LPC_GPIO2->FIOSET>>sw1) & 0x01;
      sw2status=(LPC_GPIO2->FIOSET>>sw2) & 0x01;
		if(irStatus == 1)
      {irStatus=0;
        if(counter1==MAX)
				{sprintf(buf,"Please Wait Queue Full  \n");print(buf);}
        else
        {
					if(counter1==0)
					{
						t1=LPC_RTC->SEC;
						t3=LPC_RTC->MIN;
					}
          counter1++;
          sprintf(buf,"%d:Welcome \n",counter1);print(buf);
        }
      }
		 else if (sw1status==1 && counter1!=0)//Vehicle exit
				cal_bill();
     else if(sw1status==1 && counter1==0)
		 {	sw1status=0;
        sprintf(buf,"Please enter from other side \n");print(buf);
		 }
     else if(sw2status == 1)
      {unsigned int j,total=0;
				sw2status=0;
        for(j=0;j<=i;j++)
          total=total+array[j];
				sprintf(buf,"total=%d \n",total);print(buf);
      }
    }
}
